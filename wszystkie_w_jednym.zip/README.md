# wwj - czyli wszystko w jednym
Jest to zestaw szablonów do edytora JOSM, przygotowany pod mój osobisty użytek.

# Dodawanie do edytora JOSM
Aby dodać ten zestaw szablonów do JOSM:
* Naciskamy F12 aby wejść do ustawień
* Z menu po lewej stronie wybieramy Szablony
* Po prawej stronie przy polu aktywne klikamy w symbol +
* W polu Adres/URL wklejamy następujący link: https://raw.githubusercontent.com/Maerek/wwj/main/wszystkie_w_jednym.zip
* Możemy też nadać tam nazwę jeśli chcemy
* Klikamy przycisk zatwierdź i zamykamy panel ustawień

# Logotypy firm
Logotypy firm są zastrzeżonym symbolem danych przedsiębiorstw.
